<?php

namespace App\Constants;

class LanguageConst {
    const NOT_REMOVABLE = "en";
    const NOT_REMOVABLE_CODE = "English";
}